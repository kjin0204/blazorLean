# &lt;InputFile&gt;

This is a prototype for a file input component that may be added to Blazor in the future.

For installation and usage information, see [this blog post](http://blog.stevensanderson.com/2019/09/13/blazor-inputfile/).
