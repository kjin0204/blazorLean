﻿using ChartJs.Blazor.ChartJS.Common;

namespace ChartJs.Blazor.ChartJS.BubbleChart
{
    public class BubbleOptions : BaseConfigOptions
    {
    }
}