﻿namespace ChartJs.Blazor.ChartJS.Common.Handlers.OnClickHandler
{
    /// <summary>
    /// Specifies how clicking items is handled
    /// </summary>
    public interface IClickHandler
    {
    }
}