﻿namespace ChartJs.Blazor.ChartJS.Common.Handlers.OnHover
{
    /// <summary>
    /// Specifies how hovering on items is handled
    /// </summary>
    public interface IHoverHandler
    {
    }
}