﻿using ChartJs.Blazor.ChartJS.Common;

namespace ChartJs.Blazor.ChartJS.MixedChart
{
    public class MixedOptions : BaseConfigOptions
    {
    }
}