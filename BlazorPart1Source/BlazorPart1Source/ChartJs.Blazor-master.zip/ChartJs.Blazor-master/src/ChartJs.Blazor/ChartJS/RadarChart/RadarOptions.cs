﻿using ChartJs.Blazor.ChartJS.Common;

namespace ChartJs.Blazor.ChartJS.RadarChart
{
    public class RadarOptions : BaseConfigOptions
    {
        public Scale Scale { get; set; }
    }
}