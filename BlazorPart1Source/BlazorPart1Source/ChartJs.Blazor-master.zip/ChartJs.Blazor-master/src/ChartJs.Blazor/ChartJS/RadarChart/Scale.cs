﻿using ChartJs.Blazor.ChartJS.Common.Axes.Ticks;

namespace ChartJs.Blazor.ChartJS.RadarChart
{
    public class Scale
    {
        public CartesianTicks Ticks { get; set; }
    }
}