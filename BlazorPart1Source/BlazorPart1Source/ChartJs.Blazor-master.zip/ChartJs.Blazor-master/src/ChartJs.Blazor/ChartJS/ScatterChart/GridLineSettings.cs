﻿namespace ChartJs.Blazor.ChartJS.ScatterChart
{
    public class GridLineSettings
    {
        public bool DrawOnChartArea { get; set; }
    }
}