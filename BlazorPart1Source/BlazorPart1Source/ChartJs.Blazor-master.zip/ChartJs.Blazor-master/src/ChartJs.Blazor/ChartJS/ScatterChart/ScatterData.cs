﻿using System.Collections.Generic;

namespace ChartJs.Blazor.ChartJS.ScatterChart
{
    public class ScatterData
    {
        public List<ScatterDataset> Datasets { get; set; } = new List<ScatterDataset>();
    }
}