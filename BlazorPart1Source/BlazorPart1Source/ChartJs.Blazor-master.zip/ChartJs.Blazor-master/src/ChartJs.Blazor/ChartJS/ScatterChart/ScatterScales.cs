﻿using System.Collections.Generic;

namespace ChartJs.Blazor.ChartJS.ScatterChart
{
    public class ScatterScales
    {
        public List<ScatterAxis> XAxes { get; set; }
        public List<ScatterAxis> YAxes { get; set; }
    }
}