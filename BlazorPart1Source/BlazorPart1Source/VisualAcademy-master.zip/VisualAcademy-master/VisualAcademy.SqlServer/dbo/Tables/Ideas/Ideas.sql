﻿CREATE TABLE [dbo].[Ideas]
(
	[Id] INT NOT NULL PRIMARY KEY Identity(1, 1),
	Note NVarChar(Max) Null,
)
