﻿namespace VisualAcademy.Pages
{
    public partial class Services
    {
        public string Title { get; set; } = "서비스";

        protected override void OnInitialized()
        {
            
        }
    }
}
